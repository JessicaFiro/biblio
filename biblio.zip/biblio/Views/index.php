<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url; ?>Assets/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url; ?>Assets/css/font-awesome.min.css">
    <title>Login</title>
    <style>
        /* Estilo para la ventana emergente */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        /* Estilo para el contenido de la ventana emergente */
        .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
        }

        /* Ajuste para el botón "Recuperar Contraseña" */
        .btn-container .btn-secondary {
            display: block;
        }
    </style>
</head>

<body>
    <section class="material-half-bg">
        <div class="cover"></div>
    </section>
    <section class="login-content">
        <div class="logo">
            <h1>Bienvenido</h1>
        </div>
        <div class="login-box">
            <form class="login-form" id="frmLogin" onsubmit="frmLogin(event);">
                <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>Iniciar Sesión</h3>
                <div class="form-group">
                    <label class="control-label">USUARIO</label>
                    <input class="form-control" type="text" placeholder="Usuario" id="usuario" name="usuario" autofocus
                        required>
                </div>
                <div class="form-group">
                    <label class="control-label">CONTRASEÑA</label>
                    <input class="form-control" type="password" placeholder="Contraseña" id="clave" name="clave"
                        required>
                </div>
                <div class="alert alert-danger d-none" role="alert" id="alerta">

                </div>
                <div class="form-group btn-container">
                    <button class="btn btn-primary btn-block" type="submit"><i
                            class="fa fa-sign-in fa-lg fa-fw"></i>Login</button>
                </div>

                <div class="form-group btn-container">
                    <button class="btn btn-secondary btn-block" type="button" onclick="mostrarFormulario()">Recuperar
                        Contraseña</button>
                </div>

            </form>
        </div>
    </section>

    <!-- Ventana emergente -->
    <div id="recuperarContrasenaModal" class="modal">
        <div class="modal-content">
            <h3>Recuperar Contraseña</h3>
            <form id="frmRecuperarContrasena" onsubmit="enviarRecuperacionContrasena(event);">
                <div class="form-group">
                    <label for="usuarioRecuperar">Nombre de Usuario</label>
                    <input type="text" class="form-control" id="usuarioRecuperar" name="usuarioRecuperar" required>
                </div>
                <div class="form-group">
                    <label for="correoRecuperar">Correo Electrónico</label>
                    <input type="email" class="form-control" id="correoRecuperar" name="correoRecuperar" required>
                </div>
                <button type="submit" class="btn btn-primary">Recuperar Contraseña</button>
            </form>
            <button onclick="cerrarModal()" class="btn btn-secondary">Cerrar</button>
        </div>
    </div>

    <!-- Essential javascripts for application to work-->
    <script src="<?php echo base_url; ?>Assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo base_url; ?>Assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url; ?>Assets/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo base_url; ?>Assets/js/pace.min.js"></script>
    <script>
        const base_url = '<?php echo base_url; ?>';
    </script>
    <script src="<?php echo base_url; ?>Assets/js/login.js"></script>
    <script type="text/javascript">
        // Login Page Flipbox control
        $('.login-content [data-toggle="flip"]').click(function () {
            $('.login-box').toggleClass('flipped');
            return false;
        });

        function mostrarFormulario() {
            document.getElementById("recuperarContrasenaModal").style.display = "block";
            
          
        }

        function cerrarModal() {
            document.getElementById("recuperarContrasenaModal").style.display = "none";
        }

        function enviarRecuperacionContrasena(event) {
            // Agrega aquí la lógica para enviar la recuperación de contraseña
            // Puedes prevenir el envío del formulario utilizando event.preventDefault();
            if Usuario = loquehay en la base datos {
                // Metodo para enviar contraseña al correo electronico proporcionado

                //Va a ver si el correo es real y existe
                // Va a decifrar la contraseña SHA256
                // La va a enviar al correo electronico
                // Volver a encriptar
            } else usuario != loquehay en la base datos
            //se jodio 
            print("Usuario no existe")
        }
    </script>
</body>

</html>










