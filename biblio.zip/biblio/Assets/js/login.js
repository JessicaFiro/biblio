function frmLogin(e) {

    e.preventDefault();
    const usuario = document.getElementById("usuario");
    const clave = document.getElementById("clave");
    if (usuario.value == "") {
        clave.classList.remove("is-invalid");
        usuario.classList.add("is-invalid");
        usuario.focus();
    } else if (clave.value == "") {
        usuario.classList.remove("is-invalid");
        clave.classList.add("is-invalid");
        clave.focus();
    } else {
        const url = base_url + "Usuarios/validar";
        const frm = document.getElementById("frmLogin");
        const http = new XMLHttpRequest();
        http.open("POST", url, true);
        http.send(new FormData(frm));
        http.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                const res = JSON.parse(this.responseText);
                if (res.icono == "success") {
                    window.location = base_url + "Configuracion/admin";
                } else {
                    document.getElementById("alerta").classList.remove("d-none");
                    document.getElementById("alerta").innerHTML = res.msg;
                }
            }
        }
    }
}

// Función para mostrar el formulario de recuperación de contraseña
function mostrarFormulario() {
    const formularioRecuperacion = document.getElementById("recuperarContrasenaForm");
    formularioRecuperacion.style.display = "block";
}

// Función para enviar la solicitud de recuperación de contraseña al servidor
function enviarRecuperacionContrasena(e) {
    e.preventDefault();

    // Obtener los valores de usuario y correo electrónico desde el formulario
    const usuarioRecuperar = document.getElementById("usuarioRecuperar").value;
    const correoRecuperar = document.getElementById("correoRecuperar").value;

    // Validar los datos aquí (por ejemplo, verificar si el usuario y el correo existen en la base de datos).

    // Construir el objeto de solicitud para enviar al servidor
    const solicitudRecuperacion = {
        usuarioRecuperar: usuarioRecuperar,
        correoRecuperar: correoRecuperar
    };

    // Enviar la solicitud al servidor utilizando AJAX (puedes usar fetch o XMLHttpRequest).
    // Asegúrate de que la URL y el método sean correctos según tu backend.
    fetch("/ruta/al/servidor/recuperacion", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(solicitudRecuperacion)
    })
    .then(response => response.json())
    .then(data => {
        // Procesar la respuesta del servidor aquí
        if (data.success) {
            alert(data.message); // Mostrar mensaje de éxito
            // Puedes ocultar el formulario de recuperación de contraseña si es necesario
            document.getElementById("recuperarContrasenaForm").style.display = "none";
        } else {
            alert(data.error); // Mostrar mensaje de error del servidor
        }
    })
    .catch(error => {
        console.error("Error en la solicitud:", error);
    });
}


    
   /* function Hola() {
        console.log("Botón 'Recuperar Contraseña' clicado");
        // Resto de la lógica aquí...
        alert("Por favor, póngase en contacto con el soporte para recuperar su contraseña.");
    } 

    function mostrarFormulario() {
        var formulario = document.getElementById("recuperarContrasenaForm");
        formulario.style.display = "block";
    } 

    function mostrarFormulario(e) {
        e.preventDefault();
        
        // Obtener los valores de usuario y correo electrónico desde el formulario
        const usuarioRecuperar = document.getElementById("recuperarContrasenaForm").value;
        const correoRecuperar = document.getElementById("correoRecuperar").value;
    
        // Realizar la validación de usuario y correo electrónico aquí (puedes usar AJAX si es necesario).
    
        // Envía la solicitud de recuperación de contraseña al servidor para que procese el envío por correo electrónico.
        // Asegúrate de manejar la lógica de envío de correo en el servidor, incluyendo la recuperación de la contraseña cifrada en SHA-256.
    
        // Muestra un mensaje al usuario indicando que se ha enviado un correo con las instrucciones para recuperar la contraseña.
        alert("Se ha enviado un correo con instrucciones para recuperar la contraseña.");
        
        // Limpia el formulario o realiza cualquier otra acción necesaria.
        document.getElementById("frmRecuperarContrasena").reset();
        
        // Puedes ocultar el formulario de recuperación de contraseña después de completar el proceso.
        document.getElementById("recuperarContrasenaForm").style.display = "none";
    } */
    
    
    